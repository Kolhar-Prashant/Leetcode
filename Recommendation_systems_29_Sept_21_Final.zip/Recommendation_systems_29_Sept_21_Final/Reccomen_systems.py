from flask import Flask, render_template, request, redirect, url_for
from flask_mysql_connector import MySQL
import openpyxl as op
import time

app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '1234'
app.config['MYSQL_DB'] = 'market'
mysql = MySQL(app)

def fetch_data(query,ins=0):
    conn = mysql.connection
    cur = conn.cursor()
    cur.execute(query)
    if ins != 1:
        return cur.fetchall()
    conn.commit()

def recommend_prod_fun(parent):
    def recommend_products(parent, child):
        comb_cnt = 0
        parent_cnt = 0
        for trans in Dataset:
            if parent in trans and child in trans:
                comb_cnt += 1
            if parent in trans:
                parent_cnt += 1
        conf = comb_cnt / parent_cnt
        if conf >= PARAMETERS['Confidence']:
            return child

    Dataset = Transaction_Dataset
    item_list = []
    recommend_prod_list = []
    for trans in Dataset:
        for product in trans:
            if product not in item_list:
                item_list.append(product)

    indx = 0
    while indx != len(item_list):
        if item_list[indx] != parent:
            child = recommend_products(parent, item_list[indx])
            if child != None:
                recommend_prod_list.append(child)
        indx += 1
    return (recommend_prod_list)

#--------------------------------------------Helper functions----------------------------------------------------------------

@app.route('/')
def Index():
    return render_template("Login_.html")

@app.route('/Login_', methods=['GET','POST'])
def Login_():
    username = ''
    password = ''
    if request.method == 'POST':
        username = request.form['uname']
        password = request.form['pswd']
    query = "Select userid, username, password from market.user where username = '"+username+ "' and password = '" + str(password) +"'"
    result = fetch_data(query)
    if len(result) > 0:
        T = result[0]
        global_user_id.append(T[0])
        global_username.append(username)   # username added to list.
        return render_template("Frame1_.html", uname=username, msg="Welcome, Enjoy shopping with us.")
    else:
        return redirect(url_for('Index'))

@app.route('/search_product',methods=['GET','POST'])
def search_product():
    prod_name = ""
    name = ""
    if request.method == 'POST':
        prod_name = request.form['prodname']
        if " " in prod_name:
            prod_name = prod_name.replace(" ","_")
        if prod_name not in item_list:
            msg = prod_name+" is not available in store."
            return render_template("Frame1_.html", uname=global_username[0], msg=msg)
        else:
            return render_template("Products_table_.html", prod_name=prod_name, uname=global_username[0], cart=cart)

@app.route('/homepage',methods=['GET','POST'])
def homepage():
    msg = "Welcome"
    return render_template("Frame1_.html", uname=global_username[0], msg=msg, cart=cart)

@app.route('/Combination_recommend',methods=['GET','POST'])
def Combination_recommend():
    items_purchased = list(cart)
    #print("items in carts",items_purchased)
    if len(items_purchased) >= 2:
        supp = 2
        item_list = set()
        Dict = {}

        for trans in Transaction_Dataset:
            for prod in trans:
                if prod not in items_purchased:
                    item_list.add(prod)
                    Dict[prod] = 0

        item_list = list(item_list)
        for products in item_list:
            for trans in Transaction_Dataset:
                Valid = True
                for items in items_purchased:
                    if items not in trans:
                        Valid = False
                if Valid:
                    if products in trans:
                        Dict[products] += 1
        Combination_recommended_list = []
        for product, freq in Dict.items():
            if freq >= supp:
                Combination_recommended_list.append(product)
        #print("combo",Combination_recommended_list)
        if len(Combination_recommended_list) > 0:
            prod_list = Combination_recommended_list
            return render_template("combo_rec1_.html", prod_list=prod_list)
        else:
            msg="No recommended products available for combination of items in cart !"
            return render_template("Frame1_.html", uname=global_username[0], msg=msg, cart=cart)
    else:
        msg="To calculate combination recommendation two or more products are required in cart."
        return render_template("Frame1_.html", uname=global_username[0], msg=msg, cart=cart)

@app.route('/recommend_item',methods=['GET','POST'])
def recommend_item():
    name = ""
    itemname = ""
    recommended_prod_list = []
    prod_name = ""
    msg = ""
    if request.method == 'POST':
        if 'Buy_item' in request.form:
            purchased_item = request.form['Buy_item']
            purchased_item = purchased_item.strip()
            cart.add(purchased_item)
            msg = purchased_item+" was added to cart."
            itemname = request.form['itemname_buy']
        if 'itemname' in request.form:
            itemname = request.form['itemname']
            itemname= itemname.strip()
        START_TIME = time.time()
        support_cnt = Support_cnt[itemname]

        if support_cnt > PARAMETERS['Support']:
            recommended_prod_list = recommend_prod_fun(itemname)  #using Apyori algorithm to recommend products.
            END_TIME = time.time()
            ELASPED_TIME = round(END_TIME - START_TIME,4)
            Tot_records = LIMIT[0]
            return render_template('Recommendation_table_.html',uname=global_username[0], prod_name=itemname,recommended_prod_list=recommended_prod_list,cart=cart,ELASPED_TIME=ELASPED_TIME,LIMIT = Tot_records, Support=PARAMETERS['Support'], Confidence=PARAMETERS['Confidence'],msg=msg)
        else:
            #print("inside here")
            #return redirect(url_for('search_product'))
            return render_template("Frame1_.html", uname=global_username[0], msg="No recommended items available for "+str(itemname)+" in store.",cart=cart)

@app.route('/display_chart',methods=['GET','POST'])
def display_chart():
    #print("inside dsiplay chart")
    name = ""
    parent = ""
    child = ""
    combo_cnt = 0
    parent_cnt = 0
    prod_list = []
    recommended_prod_list = []
    clicked_item = ""
    if request.method == 'POST':
        parent = request.form['item_name1']
        parent = parent.strip()
        child  = request.form['rec_itemname']
        child = child.strip()
        if 'Buy_item' in request.form:
            temp_cart.append(request.form['Buy_item'])
        recommended_prod_list = recommend_prod_fun(parent)
        for trans in Transaction_Dataset:
            if parent in trans and child in trans:
                combo_cnt += 1
            if parent in trans:
                parent_cnt += 1
        prod_list = [["Recommended product","Parent product"],[parent + " with " + child, combo_cnt],["Others products with "+ parent,parent_cnt]]
        clicked_item = request.form['rec_itemname']
        if clicked_item not in temp_cart:
            temp_cart.append(clicked_item)
    return render_template("Products_table_with_charts_.html",uname=global_username[0], prod_name=parent, recommended_prod_list=recommended_prod_list, prod_list=prod_list,cart=cart,clicked_item=clicked_item)

@app.route('/Add_to_cart',methods=['GET','POST'])
def Add_to_cart():
    name = ""
    msg = ""
    if request.method == 'POST':
        name = request.form['Buy_item']
        cart.add(name)
        name = name.capitalize()
        msg = name + " was added to cart"
    return render_template("Frame1_.html", uname=global_username[0], msg=msg, cart=cart)

@app.route('/Search_Recomm_item',methods=['GET','POST'])
def Search_Recomm_item():
    username = ""
    msg = ""
    if request.method == 'POST':
        name = request.form['Buy_item']
        name = name.strip()
        username = request.form['username_1']
        cart.add(name)
        name = name.capitalize()
        #print("inside search recom",name)
        msg = name+"was added to cart"
    return render_template("Frame1_.html", uname=global_username[0], msg=msg, cart=cart)

@app.route('/add_click_item',methods=['GET','POST'])
def add_click_item():
    prod = temp_cart[-1]
    if prod not in cart:
        cart.add(prod)
    msg = temp_cart[-1]+" was added to cart"
    return render_template("Frame1_.html", uname=global_username[0], msg=msg, cart=cart)

@app.route('/Purchase_Products',methods=['GET','POST'])
def Purchase_Products():
    L = list(cart)
    msg = ""
    if len(L) > 0:
        Purchased_prod_list = ", ".join(L)
        Purchased_prod_list = Purchased_prod_list.replace("_"," ")
        query = "insert into market.transactions (transactions,userid) values ('" + Purchased_prod_list + "'," + str(global_user_id[0])+ ")"
        fetch_data(query,1)
        msg = "Items in cart were purchased."
        cart.clear()
    else:
        msg = "Cart is empty !"
    return render_template("Frame1_.html", uname=global_username[0], msg=msg)

@app.route('/Empty_cart',methods=['GET','POST'])
def Empty_cart():
    cart.clear()
    msg = "Cart was cleared. Go purchase something !"
    return render_template("Frame1_.html", uname=global_username[0], msg=msg, cart=cart)

@app.route('/Register', methods=['GET','POST'])
def Register():
    msg = "Fill out the form"
    if request.method == 'POST':
        username = request.form['uname']
        password = request.form['pswd']
        repasswrd = request.form['re_pswd']
        if password == repasswrd:
            query = "insert into market.user (username,password) values('"+username+"','"+password+"')"
            fetch_data(query,1)
            msg = "User registered sucessfully"
        else:
            msg = "Password mismatch! Try again"
    return render_template("Registration_.html", msg=msg)

@app.route('/Logout')
def Logout():
    cart.clear()
    global_user_id.clear()
    return redirect(url_for('Index'))

if __name__ == "__main__":

    ws = op.load_workbook(r'Data1.xlsx')
    sheet = ws.active
    LIMIT = [5000]  # provide limit value here.
    Transaction_Dataset = []

    for row in range(2, sheet.max_row):
        tot_items = sheet.cell(row=row, column=1)
        Transaction = []
        for items in range(2, int(tot_items.value) + 2):
            item_name = sheet.cell(row=row, column=items).value
            item_name = item_name.replace(' ', '_')
            Transaction.append(item_name)
        Transaction_Dataset.append(Transaction)
        if row == LIMIT[0]:
            break

    PARAMETERS = {"Support":0.1,"Confidence":0.2}

    item_list = []
    recommend_prod_list = []
    Prod_cnt_dict = {}
    Total_trans_cnt=0
    G_parent_name = []
    cart = set()
    global_user_id = []
    global_username = []    # When user login his/her name will be stored in this list.
    temp_cart = []

    for trans in Transaction_Dataset:
        Total_trans_cnt+=1
        for product in trans:
            if product not in item_list:
                item_list.append(product)
            if product not in Prod_cnt_dict:
                Prod_cnt_dict[product]=1
            else:
                Prod_cnt_dict[product]+=1
    Support_cnt = {}
    for prod, count in Prod_cnt_dict.items():
        Support_cnt[prod] = count / len(Transaction_Dataset)
    app.run(debug=False)
